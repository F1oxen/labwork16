using System.Windows;
using AuthLibrary;

namespace CinemaApp;

public partial class MainWindow : Window
{
    private const string ConnectionString =
        "Server=mssql;Database=ispp4109;User Id=ispp4109;Password=4109;TrustServerCertificate=True;";

    private readonly AuthService _authService = new(ConnectionString);

    public MainWindow()
    {
        InitializeComponent();
    }

    private void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        string login = LoginTextBox.Text.Trim();
        string password = PasswordBox.Password;

        if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Введите логин и пароль");
            return;
        }

        try
        {
            if (_authService.Register(login, password))
            {
                MessageBox.Show("Регистрация выполнена");
                LoginTextBox.Clear();
                PasswordBox.Clear();
            }
            else
            {
                MessageBox.Show("Пользователь с таким логином уже существует");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }
}
