using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;

namespace AuthLibrary;

public class AuthService
{
    private const int VisitorRoleId = 1;

    private readonly string _connectionString;

    public AuthService(string connectionString)
    {
        _connectionString = connectionString;
    }

    private static string HashPassword(string password)
    {
        byte[] bytes = SHA256.HashData(Encoding.UTF8.GetBytes(password));
        return Convert.ToHexString(bytes);
    }

    public bool Register(string login, string password)
    {
        using var connection = new SqlConnection(_connectionString);
        connection.Open();

        using (var check = new SqlCommand("SELECT COUNT(1) FROM dbo.CinemaUser WHERE Login = @login", connection))
        {
            check.Parameters.AddWithValue("@login", login);
            if ((int)check.ExecuteScalar()! > 0)
            {
                return false;
            }
        }

        using var insert = new SqlCommand(
            "INSERT INTO dbo.CinemaUser (RoleId, Login, PasswordHash) VALUES (@roleId, @login, @hash)",
            connection);
        insert.Parameters.AddWithValue("@roleId", VisitorRoleId);
        insert.Parameters.AddWithValue("@login", login);
        insert.Parameters.AddWithValue("@hash", HashPassword(password));
        insert.ExecuteNonQuery();

        return true;
    }
}
