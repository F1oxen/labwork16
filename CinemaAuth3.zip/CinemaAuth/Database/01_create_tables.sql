USE ispp4109;
GO

CREATE TABLE dbo.CinemaUserRole (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CinemaUserRole PRIMARY KEY,
    Name NVARCHAR(20) NOT NULL
);
GO

CREATE TABLE dbo.CinemaPrivilege (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CinemaPrivilege PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE dbo.CinemaRolePrivilege (
    RoleId INT NOT NULL,
    PrivilegeId INT NOT NULL,
    CONSTRAINT PK_CinemaRolePrivilege PRIMARY KEY (RoleId, PrivilegeId),
    CONSTRAINT FK_CinemaRolePrivilege_Role FOREIGN KEY (RoleId) REFERENCES dbo.CinemaUserRole (Id),
    CONSTRAINT FK_CinemaRolePrivilege_Privilege FOREIGN KEY (PrivilegeId) REFERENCES dbo.CinemaPrivilege (Id)
);
GO

INSERT INTO dbo.CinemaUserRole (Name) VALUES
(N'Посетитель'),
(N'Билетер'),
(N'Администратор');
GO

INSERT INTO dbo.CinemaPrivilege (Name) VALUES
(N'доступ в личный кабинет'),
(N'проверка билетов'),
(N'просмотр списка фильмов'),
(N'добавление пользователей'),
(N'редактирование пользователей');
GO

INSERT INTO dbo.CinemaRolePrivilege (RoleId, PrivilegeId) VALUES
(3, 1), (3, 4), (3, 5),
(2, 1), (2, 2), (2, 3),
(1, 1), (1, 3);
GO

CREATE TABLE dbo.CinemaUser (
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CinemaUser PRIMARY KEY,
    RoleId INT NOT NULL CONSTRAINT FK_CinemaUser_Role REFERENCES dbo.CinemaUserRole (Id),
    Login NVARCHAR(50) NOT NULL CONSTRAINT UQ_CinemaUser_Login UNIQUE,
    PasswordHash NVARCHAR(120) NOT NULL,
    FailedLoginAttempts INT NOT NULL CONSTRAINT DF_CinemaUser_FailedLoginAttempts DEFAULT 0,
    UnlockDate DATETIME2 NULL
);
GO
