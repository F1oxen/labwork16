using System.Windows;

namespace CinemaApp;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        UpdateView();
    }

    private void UpdateView()
    {
        var user = UserSession.Instance.CurrentUser;
        bool isAuthorized = user != null;

        UserTextBlock.Text = isAuthorized ? user!.Login : "Вы не авторизованы";
        LoginButton.Visibility = isAuthorized ? Visibility.Collapsed : Visibility.Visible;
        RegisterButton.Visibility = isAuthorized ? Visibility.Collapsed : Visibility.Visible;
        LogoutButton.Visibility = isAuthorized ? Visibility.Visible : Visibility.Collapsed;
    }

    private void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        var window = new LoginWindow { Owner = this };
        if (window.ShowDialog() == true)
        {
            UpdateView();
        }
    }

    private void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        new RegisterWindow { Owner = this }.ShowDialog();
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e)
    {
        UserSession.Instance.Clear();
        UpdateView();
    }
}
