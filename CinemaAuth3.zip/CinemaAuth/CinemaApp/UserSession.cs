using AuthLibrary;

namespace CinemaApp;

public class UserSession
{
    private static readonly UserSession _instance = new();

    private UserSession() { }

    public static UserSession Instance => _instance;

    public CinemaUser? CurrentUser { get; private set; }

    public void SetCurrentUser(CinemaUser user)
    {
        CurrentUser = user;
    }

    public void Clear()
    {
        CurrentUser = null;
    }
}
