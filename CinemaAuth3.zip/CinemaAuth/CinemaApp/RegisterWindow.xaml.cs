using System.Windows;

namespace CinemaApp;

public partial class RegisterWindow : Window
{
    public RegisterWindow()
    {
        InitializeComponent();
    }

    private void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        string login = LoginTextBox.Text.Trim();
        string password = PasswordBox.Password;

        if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Введите логин и пароль");
            return;
        }

        try
        {
            if (App.AuthService.Register(login, password))
            {
                MessageBox.Show("Регистрация выполнена");
                Close();
            }
            else
            {
                MessageBox.Show("Пользователь с таким логином уже существует");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }
}
