using System.Windows;
using AuthLibrary;

namespace CinemaApp;

public partial class App : Application
{
    private const string ConnectionString =
        "Server=mssql;Database=ispp4109;User Id=ispp4109;Password=4109;TrustServerCertificate=True;";

    public static AuthService AuthService { get; } = new(ConnectionString);
}
