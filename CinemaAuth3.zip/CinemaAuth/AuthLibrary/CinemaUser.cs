namespace AuthLibrary;

public class CinemaUser
{
    public int Id { get; set; }
    public int RoleId { get; set; }
    public string Login { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public int FailedLoginAttempts { get; set; }
    public DateTime? UnlockDate { get; set; }
}
